# !/usr/bin/python3 
# coding : utf-8

import os

packages = ['php', 'curl', 'unzip']


def start():
    for elt in packages:
        try:
            os.system("clear && sleep 0.5")
            print("[+] Trying to install {} ... \n".format(elt))
            os.system("sleep 0.2 && apt-get install {} -y".format(elt))
        except:
            os.system("clear")
            print("[-] Error during installation ")
            print("[-] Please restart this scipt !!!")
            exit()


if __name__ == '__main__':
    start()
    os.system("clear && sleep 1")
    print("[+] Successful Installation !!! \n")
    choice = input(" ... Do you want start NetflixPhish Script ??? (yes or no) : ")

    if 'y' in choice:
        os.system("chmod +x * && ./NetflixPhish.sh")
    else:
        print(" ... GodBye !!!")
        exit()
